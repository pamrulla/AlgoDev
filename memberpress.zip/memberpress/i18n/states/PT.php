<?php
/**
 * Portugal Regions
 */
$states['PT'] = array(
  'NO' => _x('Norte', 'ui', 'memberpress'),
  'CE' => _x('Centro', 'ui', 'memberpress'),
  'LT' => _x('Lisboa e Vale do Tejo', 'ui', 'memberpress'),
  'AG' => _x('Algarve', 'ui', 'memberpress'),
  'AT' => _x('Alentejo', 'ui', 'memberpress'),
  'MD' => _x('Madeira', 'ui', 'memberpress'),
  'AC' => _x('Açores', 'ui', 'memberpress')
);

