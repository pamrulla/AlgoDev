<?php
/**
 * Australian states
 */
$states['AU'] = array(
  'ACT' => _x('Australian Capital Territory', 'ui', 'memberpress'),
  'NSW' => _x('New South Wales', 'ui', 'memberpress'),
  'NT'  => _x('Northern Territory', 'ui', 'memberpress'),
  'QLD' => _x('Queensland', 'ui', 'memberpress'),
  'SA'  => _x('South Australia', 'ui', 'memberpress'),
  'TAS' => _x('Tasmania', 'ui', 'memberpress'),
  'VIC' => _x('Victoria', 'ui', 'memberpress'),
  'WA'  => _x('Western Australia', 'ui', 'memberpress')
);

