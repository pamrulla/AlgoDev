<?php if(!defined('ABSPATH')) {die('You are not allowed to call this page directly.');} ?>

<div class="mp_wrapper mepr_password_reset_requested">
  <h3><?php _ex('Successfully requested password reset', 'ui', 'memberpress'); ?></h3>
  <p><?php _ex('Please click on the confirmation link that was just sent to your email address.', 'ui', 'memberpress'); ?></p>
</div>
